1. `brew install pipenv`
2. Set `ACTION_HUB_LOAD_TESTING_SIMULATED_DOWNLOAD_URL`, `ACTION_HUB_LOAD_TESTING_API_KEY`, `ACTION_HUB_LOAD_TESTING_HOST` environment variables.
3. `./load-test` and visit http://localhost:8089/
