The files in this directory are automatically generated from Looker's API definitions.

TODO: Improve this process and require the types from a real SDK.
